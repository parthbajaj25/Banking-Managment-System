from bank import Bank
from utils import read_amount, pause, line, title


def create_account_menu(bank):
    title("CREATE ACCOUNT")
    name = input("Full name: ").strip()
    phone = input("Phone number: ").strip()
    email = input("Email address: ").strip()
    pin = input("Create a 4-digit PIN: ").strip()
    print("\nAccount type")
    print("1. Savings")
    print("2. Current")
    account_type = input("Choose type: ").strip()

    if account_type not in ("1", "2"):
        print("Invalid account type.")
        return

    amount = read_amount("Opening deposit (Rs.): ", allow_zero=True)
    if amount is None:
        return

    try:
        account = bank.create_account(name, phone, email, pin, account_type, amount)
        print("\nAccount created successfully.")
        print(f"Account number : {account.account_number}")
        print(f"Account holder : {account.name}")
        print(f"Account type   : {account.account_type}")
        print(f"Opening balance: Rs. {account.balance:.2f}")
    except ValueError as error:
        print(f"Could not create account: {error}")


def customer_menu(bank):
    line()
    print("CUSTOMER LOGIN")
    account_number = input("Account number: ").strip()
    pin = input("4-digit PIN: ").strip()
    account = bank.authenticate(account_number, pin)

    if account is None:
        print("Invalid account number or PIN.")
        return

    while True:
        title(f"CUSTOMER DASHBOARD - {account.name}")
        print("1. Account overview")
        print("2. Deposit money")
        print("3. Withdraw money")
        print("4. Transfer money")
        print("5. Transaction history")
        print("6. Download account statement")
        print("7. Change PIN")
        print("8. Logout")
        choice = input("Select an option: ").strip()

        if choice == "1":
            bank.show_account(account)
        elif choice == "2":
            amount = read_amount("Deposit amount (Rs.): ")
            if amount is not None:
                bank.deposit(account, amount)
        elif choice == "3":
            amount = read_amount("Withdrawal amount (Rs.): ")
            if amount is not None:
                bank.withdraw(account, amount)
        elif choice == "4":
            recipient = input("Recipient account number: ").strip()
            amount = read_amount("Transfer amount (Rs.): ")
            if amount is not None:
                bank.transfer(account, recipient, amount)
        elif choice == "5":
            bank.show_history(account)
        elif choice == "6":
            path = bank.export_statement(account)
            print(f"Statement saved to: {path}" if path else "Could not export statement.")
        elif choice == "7":
            old_pin = input("Current PIN: ").strip()
            new_pin = input("New 4-digit PIN: ").strip()
            try:
                bank.change_pin(account, old_pin, new_pin)
                print("PIN changed successfully.")
            except ValueError as error:
                print(error)
        elif choice == "8":
            print("Logged out.")
            break
        else:
            print("Please choose a valid option.")
        pause()


def admin_menu(bank):
    title("STAFF / ADMIN MENU")
    password = input("Demo staff password: ").strip()
    if password != "bankadmin123":
        print("Access denied.")
        return

    while True:
        title("BANK OPERATIONS")
        print("1. List all accounts")
        print("2. Search account")
        print("3. Sort accounts by balance")
        print("4. View recent transactions")
        print("5. Bank summary")
        print("6. Freeze / unfreeze account")
        print("7. Export all accounts to CSV")
        print("8. Back to main menu")
        choice = input("Select an option: ").strip()

        if choice == "1":
            bank.list_accounts()
        elif choice == "2":
            number = input("Account number: ").strip()
            account = bank.find_account(number)
            if account:
                bank.show_account(account)
            else:
                print("Account not found.")
        elif choice == "3":
            bank.sort_accounts()
        elif choice == "4":
            bank.show_recent_transactions()
        elif choice == "5":
            bank.show_summary()
        elif choice == "6":
            number = input("Account number: ").strip()
            try:
                bank.toggle_account_status(number)
                print("Account status updated.")
            except ValueError as error:
                print(error)
        elif choice == "7":
            path = bank.export_accounts()
            print(f"Account list exported to: {path}" if path else "Export failed.")
        elif choice == "8":
            break
        else:
            print("Please choose a valid option.")
        pause()


def main():
    bank = Bank()
    while True:
        title("BANKING MANAGEMENT SYSTEM")
        print("1. Open a new account")
        print("2. Customer login")
        print("3. Staff / admin login")
        print("4. Search account number")
        print("5. Save and exit")
        choice = input("Select an option: ").strip()

        if choice == "1":
            create_account_menu(bank)
            pause()
        elif choice == "2":
            customer_menu(bank)
        elif choice == "3":
            admin_menu(bank)
        elif choice == "4":
            number = input("Account number: ").strip()
            account = bank.find_account(number)
            if account:
                print(f"Account found: {account.name} ({account.account_type})")
                print("For privacy, balance and personal details require customer login.")
            else:
                print("Account not found.")
            pause()
        elif choice == "5":
            if bank.save():
                print("All records saved. Goodbye.")
                break
            print("Could not save records. Please try again.")
            pause()
        else:
            print("Invalid option.")
            pause()


if __name__ == "__main__":
    main()
